<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <meta property="og:title" content="Dorin Web Portfolio">
  <meta name="description" content="A Passionate Software Developer, Entrepreneur and Coder. I love to play with coding, building software, and focusing on learning new technologies. Currently I am working as a Senior Software Engineer." />

  <meta property="og:image" content="">

  <meta name="author" content="DORIN" />
  <meta name="keywords" content="HTML, CSS, JavaScript, portfolio" />


  <title>Dorin || Software Engineer</title>
  <!-- for FF, Chrome, Opera -->
  <link rel="icon" type="image/png" href="" sizes="16x16">
  <link rel="icon" type="image/png" href="" sizes="32x32">

  <!-- for IE -->
  <link rel="icon" type="image/x-icon" href="">
  <link rel="shortcut icon" type="image/x-icon" href="">

  <style>
    p.a {
      font-style: normal;
    }

    p.b {
      font-style: italic;
    }

    p.c {
      font-style: Georgia;
    }
  </style>

  <link rel="stylesheet" href="./assets/css/color.css" />
  <link rel="stylesheet" href="./assets/css/style.css" />
  <link href="https://fonts.googleapis.com/css?family=Roboto|Roboto+Mono|Inconsolata" rel="stylesheet" />
  <link href="https://cdn.materialdesignicons.com/2.0.46/css/materialdesignicons.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script type="text/javascript">
    (function(d, w, c) {
      (w[c] = w[c] || []).push(function() {
        try {
          w.yaCounter41478434 = new Ya.Metrika({
            id: 41478434,
            clickmap: true,
            trackLinks: true,
            accurateTrackBounce: true,
            webvisor: true,
            trackHash: true
          });
        } catch (e) {}
      });
      var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function() {
          n.parentNode.insertBefore(s, n);
        };
      s.type = "text/javascript";
      s.async = true;
      s.src = "../../mc.yandex.ru/metrika/watch.js";
      if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f, false);
      } else {
        f();
      }
    })(document, window, "yandex_metrika_callbacks");
  </script>
  <div><img src="https://mc.yandex.ru/watch/41478434" style="position:absolute; left:-9999px;" alt="" /></div>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />




  <!--Main menu-->
  <div class="menu">
    <div class="container">
      <div class="row">
        <div class="menu__wrapper d-none d-lg-block col-md-12">
          <nav class="">
            <ul>
              <li><a href="#hello">Hello</a></li>
              <li><a href="#resume">Skills Set</a></li>
              <li><a href="projects.php#portfolio">Recent projects</a></li>
              <li><a href="projects.php#testimonials">testimonials</a></li>
              <li><a href="blog.php">blog</a></li>
              <li><a href="#contact">Contact</a></li>
            </ul>
          </nav>
        </div>
        <div class="menu__wrapper col-md-12 d-lg-none">
          <button type="button" class="menu__mobile-button">
            <span><i class="fa fa-bars" aria-hidden="true"></i></span>
          </button>
        </div>
      </div>
    </div>
  </div>
  <!--Main menu-->

  <!-- Mobile menu -->
  <div class="mobile-menu d-lg-none">
    <div class="container">
      <div class="mobile-menu__close">
        <span><i class="mdi mdi-close" aria-hidden="true"></i></span>
      </div>
      <nav class="mobile-menu__wrapper">
        <ul>
          <li><a href="#hello">Hello</a></li>
          <li><a href="#resume">Skills Set</a></li>
          <li><a href="#portfolio">Recent projects</a></li>
          <li><a href="#testimonials">testimonials</a></li>
          <li><a href="blog.php">blog</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </nav>
    </div>
  </div>
  <!-- Mobile menu -->

  <!--Header-->
  <header class="main-header">
    <div class="container">
      <div class="row personal-profile">
        <div class="col-md-4 personal-profile__avatar">
          <img class="" src="./assets/img/img_avatar.jpg" alt="avatar" />
        </div>
        <div class="col-md-8">
          <p class="personal-profile__name">DORIN Gavrilita</p>
          <p class="personal-profile__work">Student</p>
          <div class="personal-profile__contacts">
            <dl class="contact-list contact-list__opacity-titles">
              <dt>Age:</dt>
              <dd>20</dd>
              <dt>Phone:</dt>
              <dd><a href="tel:+373 67496303">+373 67496303</a></dd>
              <dt>Email:</dt>
              <dd><a href="mailto:gavrilitadorin5@gmail.com">gavrilitadorin5@gmail.com</a></dd>
              <dt>Address:</dt>
              <dd>Moldova, Balti </dd>
              <dt></dt>
              <dd>
                <p class="personal-profile__social">
                  <a href="https://github.com/DorinGavrilita" target="_blank"><i class="fa fa-github"></i></a>
                  <a href="https://www.linkedin.com/in/dorin-gavrilita-636476218/" target="_blank">
                    <i class="fa fa-linkedin-square"></i></a>
                  <a href="https://www.facebook.com/profile.php?id=100008440155085" target="_blank">
                    <i class="fa fa-facebook-square"></i></a>
                </p>
              </dd>
            </dl>
          </div>
          <div class="wish">
            <?php
            $t = date("H");

            if ($t < "10") {
              echo "Have a good morning!";
            } elseif ($t < "20") {
              echo "Have a good day!";
            } else {
              echo "Have a good night!";
            }
            ?>
          </div>
        </div>
      </div>
    </div>
  </header>
  <!--Header-->

  <!--Hello-->
  <section id="hello" class="container section">
    <div class="row">
      <div class="col-md-10">
        <h2 id="hello_header" class="section__title">Hi_</h2>
        <p align=" justify" class="section__description">

          I am DORIN. A Passionate Software Developer, Entrepreneur and Programmer. I love to play with coding, building
          software, and focusing on learning new technologies. Currently I am working in a prominent IT enabled Business
          company known by HUSSAINS™ Business Consultants Ltd, as a Senior Software Engineer from past 2 years. In
          addition, I am trying to establish my own AI based software company entitled with Triangle Technologies
          Ltd.<br>


          <br>
      </div>
    </div>
  </section>
  <!--Hello-->

  <hr />

  <!--Resume-->
  <section id="resume" class="container section">
    <div class="row">
      <div class="col-md-10">
        <h2 id="resume_header" class="section__title">Skills Set</h2>
        <p class="section__description">
          My work experience comprised of various skills set like Android Apps Development with integrating APIs,
          Building dynamic and responsive websites and so on!
          I have gained further knowledge aside from my experience,through following:</p>
        <p class="c">
          
          <?php

          $arrSkill = array(
            "Object Oriented Programming (OOP).",

            "Experience on Android – Retrofit2, Data Binding, Room, Google Map, Layout and
          Design, NFC Read and Write.",

            "Expertise in PHP (Node.js, REST API, HTML, CSS, Bootstrap, JS, WordPress, Laravel,
          CodeIgnitor jQuery).",

            "Most used language for Programming: Java, PHP, ASP.NET (MVC), C, C++.",

            "Experience on building professional Application Spring Boot with java persistence
          API (JPA).",

            "Experience on Data Access object (DAO), Crud Repository and Unit testing in java
          framework jUnit.",

            "Experience on RESTful API. Knowledge on Web API.",

            "Familiar with Version Controlling System GitHub and bitbucket.",

            "Language proficiency: Russian, Romanian, English."
          );


          for ($i = 0; $i < count($arrSkill); $i++) {

            echo '<br><span>&#x2714;</span>' .  $arrSkill[$i];
          }


          ?>

        </p>

      </div>
    </div>

    <div class="row">
      <div class="col-md-8 section__resume resume-list">
        <h3 class="resume-list_title">PRESENT JOB STATUS</h3>
        <div class="resume-list__block">
          <p class="resume-list__block-title"><a href="">HUSSAINS™ BUSINESS CONSULTANTS LTD</a>
          </p>
          <p class="resume-list__block-date">Senior Software Engineer</p>
          <p class="resume-list__block-date">2018 – Present</p>
          <p align=" justify" class="c">HUSSAINS™ Business Consultants Ltd. encompasses a group of highly motivated and
            experienced professionals in the field of Software, accountancy, tax, finance and corporate law that
            provides services on core areas of assurance, management consulting, tax advisory, BPO and consulting to
            government agencies, corporate houses and net worth individuals in Bangladesh. </P>
        </div>
        <div class="resume-list__block">
          <p class="resume-list__block-title"> <a href="">Triangle Technologies Ltd</a></p>
          <p class="resume-list__block-date">Chairman & CEO</p>
          <p class="resume-list__block-date">2019 – Present</p>
          <p align=" justify" class="c">Triangle Technologies Ltd is one of the few IT system integration, professional
            service and software development companies in Bangladesh that works with Enterprise systems and companies.
            As a privately owned Software company, Triangle Technologies Ltd provides IT Consultancy, software design
            and development as well as professional services, hardware deployment and maintenance. </P>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-8 section__resume resume-list">
        <h3 class="resume-list_title">Previous Employment</h3>
        <div class="resume-list__block">
          <p class="resume-list__block-title">Qbytes</p>
          <p class="resume-list__block-date">2015 - 2017</p>
          <p>
            Web Developer
          </p>
        </div>

      </div>
    </div>

    <div class="row">
      <div class="col-md-8 section__resume resume-list">
        <h3 class="resume-list_title">education</h3>
        <div class="resume-list__block">
          <p class="resume-list__block-title">International University of Business Agriculture and Technology (IUBAT)
          </p>
          <p class="resume-list__block-date">2014 - 2018</p>
          <p class="resume-list__block-date">BSc in Computer Science and Engineering</p>
        </div>
        <div class="resume-list__block">
          <p class="resume-list__block-title">TMKM (HSC)</p>
          <p class="resume-list__block-date">2012 - 2014</p>
          <p class="resume-list__block-date">Group: Science</p>
        </div>
        <div class="resume-list__block">
          <p class="resume-list__block-title">IIEC (SSC)</p>
          <p class="resume-list__block-date">2010 - 2012</p>
          <p class="resume-list__block-date">Group: Science</p>

        </div>
      </div>
    </div>

    <div class="row section__resume progress-list js-progress-list">
      <div class="col-md-12">
        <h3 class="progress-list__title">General skills</h3>
      </div>
      <div class="col-md-5 mr-auto">
        <div class="progress-list__skill">
          <p>
            <span class="progress-list__skill-title">Android</span>
            <span class="progress-list__skill-value">85%</span>
          </p>
          <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">
            </div>
          </div>
        </div>
        <div class="progress-list__skill">
          <p>
            <span class="progress-list__skill-title">JAVA</span>
            <span class="progress-list__skill-value">80%</span>
          </p>
          <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100">
            </div>
          </div>
        </div>
        <div class="progress-list__skill">
          <p>
            <span class="progress-list__skill-title">java script</span>
            <span class="progress-list__skill-value">90%</span>
          </p>
          <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100">
            </div>
          </div>
        </div>
        <div class="progress-list__skill">
          <p>
            <span class="progress-list__skill-title">Dart</span>
            <span class="progress-list__skill-value">80%</span>
          </p>
          <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-5 mr-auto">
        <div class="progress-list__skill">
          <p>
            <span class="progress-list__skill-title">ASP.NET</span>
            <span class="progress-list__skill-value">75%</span>
          </p>
          <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">
            </div>
          </div>
        </div>
        <div class="progress-list__skill">
          <p>
            <span class="progress-list__skill-title">PHP</span>
            <span class="progress-list__skill-value">85%</span>
          </p>
          <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100">
            </div>
          </div>
        </div>
        <div class="progress-list__skill">
          <p>
            <span class="progress-list__skill-title">Flutter</span>
            <span class="progress-list__skill-value">90%</span>
          </p>
          <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100">
            </div>
          </div>
        </div>
        <div class="progress-list__skill">
          <p>
            <span class="progress-list__skill-title">Laravel</span>
            <span class="progress-list__skill-value">70%</span>
          </p>
          <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--Resume-->


  <!--Contact-->
  <div class="background" style="background-image: url(./assets/img/img_bg_main.jpg)">
    <div id="contact" class="container section">
      <div class="row">
        <div class="col-md-12">
          <p id="contacts_header" class="section__title">Get in touch_</p>
        </div>
      </div>
      <div class="row contacts">
        <div class="col-md-5 col-lg-4">
          <div class="contacts__list">
            <dl class="contact-list">
              <dt>Phone:</dt>
              <dd><a href="tel:+373 67496303">+373 67496303</a></dd>
              <dt>GitHub</dt>
              <dd><a href="https://github.com/DorinGavrilita">DorinGavrilita</a></dd>
              <dt>Email:</dt>
              <dd><a href="gavrilitadorin5@gmail.com">gavrilitadorin5@gmail.com</a></dd> <br>
              <dt></dt>
              <dd>
                <div class="contacts__social">
                  <p class="personal-profile__social">
                    <a href="https://github.com/DorinGavrilita" target="_blank"><i class="fa fa-github fa-2x"></i></a>&nbsp;
                    &nbsp; <a href="https://www.linkedin.com/in/dorin-gavrilita-636476218/" target="_blank">
                      <i class="fa fa-linkedin-square fa-2x"></i></a>&nbsp;
                    &nbsp; <a href="https://www.facebook.com/profile.php?id=100008440155085" target="_blank">
                      <i class="fa fa-facebook-square fa-2x"></i></a>
                  </p>
                </div>
              </dd>
            </dl>
          </div>

        </div>
        <div class="col-md-7 col-lg-5">

          <div class="contacts__form">
            <p class="contacts__form-title">Or just write me a letter here_</p>
            <div class="msg"></div>
            <form class="js-form" method="post" action="mail_handler.php">
              <div class="form-group">
                <input class="form-field js-field-name" name="name" id="name" type="text" placeholder="Your name" required="" />
                <span class="form-validation"></span>
                <span class="form-invalid-icon"><i class="mdi mdi-close" aria-hidden="true"></i></span>
              </div>
              <div class="form-group">
                <input class="form-field js-field-email" name="email" id="email" type="email" placeholder="Your e-mail" required="" />
                <span class="form-validation"></span>
                <span class="form-invalid-icon"><i class="mdi mdi-close" aria-hidden="true"></i></span>
              </div>
              <div class="form-group">
                <textarea class="form-field js-field-message" name="message" id="message" placeholder="Type the message here" required=""></textarea>
                <span class="form-validation"></span>
                <span class="form-invalid-icon"><i class="mdi mdi-close" aria-hidden="true"></i></span>
              </div>
              <button class="site-btn site-btn--form" id="submit" name="submit" type="submit" onclick="myFunction()" value="Send">Send</button>
            </form>
          </div>
          <div class="footer">
            <p>© 2022 DORIN. All Rights Reserved</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--Contact-->
  <script>
    function myFunction() {
      const nameInput = document.querySelector('#name');
      const emailInput = document.querySelector('#email');
      const messageInput = document.querySelector('#message');
      const msg = document.querySelector('.msg');

      if (nameInput.value === '' || emailInput.value === '' || messageInput.value === '') {
        msg.innerHTML = '';
      } else {
        msg.classList.add('error');
        msg.innerHTML = 'Your Message has been Sent!';

        // Remove error after 3 seconds
        setTimeout(() => msg.remove(), 6000);
      }


    }
  </script>

  <script src="./assets/js/jquery-2.2.4.min.js"></script>
  <script src="./assets/js/popper.min.js"></script>
  <script src="./assets/js/bootstrap.min.js"></script>
  <script src="./assets/js/menu.js"></script>
  <script src="./assets/js/jquery.waypoints.js"></script>
  <script src="./assets/js/progress-list.js"></script>
  <script src="./assets/js/section.js"></script>
  <script src="./assets/js/portfolio-filter.js"></script>
  <script src="./assets/js/slider-carousel.js"></script>
  <script src="./assets/js/mobile-menu.js"></script>

  <script src="./assets/js/mbclicker.min.js"></script>
  <script src="./assets/js/site-btn.js"></script>
  <script src="./assets/js/style-switcher.js"></script>


</html>