<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta http-equiv="X-UA-Compatible" content="ie=edge" />
	<meta property="og:title" content="Dorin Web Portfolio">
	<meta name="description" content="A Passionate Software Developer, Entrepreneur and Coder. I love to play with coding, building software, and focusing on learning new technologies. Currently I am working as a Senior Software Engineer." />

	<meta property="og:image" content="http://saadportfolio.com/IMG_20180302_3.jpg">

	<meta name="author" content="DORIN" />
	<meta name="keywords" content="HTML, CSS, JavaScript, portfolio" />


	<title>Dorin || Software Engineer</title>
	<!-- for FF, Chrome, Opera -->
	<link rel="icon" type="image/png" href="/assets/sad.png" sizes="16x16">
	<link rel="icon" type="image/png" href="/assets/sad.png" sizes="32x32">

	<!-- for IE -->
	<link rel="icon" type="image/x-icon" href="/assets/sad.ico">
	<link rel="shortcut icon" type="image/x-icon" href="/assets/sad.ico" />

	<style>
		p.a {
			font-style: normal;
		}

		p.b {
			font-style: italic;
		}

		p.c {
			font-style: Georgia;
		}
	</style>

	<link rel="stylesheet" href="./assets/css/color.css" />
	<link rel="stylesheet" href="./assets/css/style.css" />
	<link href="https://fonts.googleapis.com/css?family=Roboto|Roboto+Mono|Inconsolata" rel="stylesheet" />
	<link href="https://cdn.materialdesignicons.com/2.0.46/css/materialdesignicons.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script type="text/javascript">
		(function(d, w, c) {
			(w[c] = w[c] || []).push(function() {
				try {
					w.yaCounter41478434 = new Ya.Metrika({
						id: 41478434,
						clickmap: true,
						trackLinks: true,
						accurateTrackBounce: true,
						webvisor: true,
						trackHash: true
					});
				} catch (e) {}
			});
			var n = d.getElementsByTagName("script")[0],
				s = d.createElement("script"),
				f = function() {
					n.parentNode.insertBefore(s, n);
				};
			s.type = "text/javascript";
			s.async = true;
			s.src = "../../mc.yandex.ru/metrika/watch.js";
			if (w.opera == "[object Opera]") {
				d.addEventListener("DOMContentLoaded", f, false);
			} else {
				f();
			}
		})(document, window, "yandex_metrika_callbacks");
	</script>
	<div><img src="https://mc.yandex.ru/watch/41478434" style="position:absolute; left:-9999px;" alt="" /></div>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />




	<!--Main menu-->
	<div class="menu">
		<div class="container">
			<div class="row">
				<div class="menu__wrapper d-none d-lg-block col-md-12">
					<nav class="">
						<ul>
							<li><a href="index.php#hello">Hello</a></li>
							<li><a href="index.php#resume">Skills Set</a></li>
							<li><a href="#portfolio">Recent projects</a></li>
							<li><a href="#testimonials">testimonials</a></li>
							<li><a href="blog.php">blog</a></li>
							<li><a href="#contact">Contact</a></li>
						</ul>
					</nav>
				</div>
				<div class="menu__wrapper col-md-12 d-lg-none">
					<button type="button" class="menu__mobile-button">
						<span><i class="fa fa-bars" aria-hidden="true"></i></span>
					</button>
				</div>
			</div>
		</div>
	</div>
	<!--Main menu-->

	<!-- Mobile menu -->
	<div class="mobile-menu d-lg-none">
		<div class="container">
			<div class="mobile-menu__close">
				<span><i class="mdi mdi-close" aria-hidden="true"></i></span>
			</div>
			<nav class="mobile-menu__wrapper">
				<ul>
					<li><a href="index.php#hello">Hello</a></li>
					<li><a href="index.php#resume">Skills Set</a></li>
					<li><a href="#portfolio">Recent projects</a></li>
					<li><a href="#testimonials">testimonials</a></li>
					<li><a href="blog.php">blog</a></li>
					<li><a href="#contact">Contact</a></li>
				</ul>
			</nav>
		</div>
	</div>
	<!-- Mobile menu -->

	<!--Header-->
	<header class="main-header">
		<div class="container">
			<div class="row personal-profile">
				<div class="col-md-4 personal-profile__avatar">
					<img class="" src="./assets/img/img_avatar.jpg" alt="avatar" />
				</div>
				<div class="col-md-8">
					<p class="personal-profile__name">DORIN Gavrilita</p>
					<p class="personal-profile__work">Student</p>
					<div class="personal-profile__contacts">
						<dl class="contact-list contact-list__opacity-titles">
							<dt>Age:</dt>
							<dd>20</dd>
							<dt>Phone:</dt>
							<dd><a href="tel:+8801685040674">+373 67496303</a></dd>
							<dt>Email:</dt>
							<dd><a href="mailto:mail@mail.com">gavrilitadorin5@gmail.com</a></dd>
							<dt>Address:</dt>
							<dd>Moldova, Balti </dd>
							<dt></dt>
							<dd>
								<p class="personal-profile__social">
									<a href="https://github.com/DorinGavrilita" target="_blank"><i class="fa fa-github"></i></a>
									<a href="https://www.linkedin.com/in/dorin-gavrilita-636476218/" target="_blank">
										<i class="fa fa-linkedin-square"></i></a>
									<a href="https://www.facebook.com/profile.php?id=100008440155085" target="_blank">
										<i class="fa fa-facebook-square"></i></a>
								</p>
							</dd>
						</dl>

					</div>

				</div>
			</div>
		</div>
	</header>
	<!--Header-->


	<!--Portfolio-->
	<section id="portfolio" class="container section">
		<div class="row">
			<div class="col-md-12">
				<h2 id="portfolio_header" class="section__title">My Recent projects_</h2>
			</div>
		</div>
		<div class="row portfolio-menu">
			<div class="col-md-12">
				<nav>
					<ul>

						<li><a href="https://hrm-payroll.triangeltech.com/" data-portfolio-target-tag="landing-pages">HRM &
								Payroll
								Management System</a></li>
						<li><a href="https://mayasshoppingcenter.com/" data-portfolio-target-tag="web-sites">E-Commerce
								web-sites</a></li>
						<li><a href="http://pharmacy.triangeltech.com/" data-portfolio-target-tag="pharmacy">Pharmacy
								Management
								System</a></li>
					</ul>
				</nav>
			</div>
		</div>
		<div class="portfolio-cards">
			<div class="row project-card" data-toggle="modal" data-target="#portfolioModal" data-portfolio-tag="web-sites">
				<div class="col-md-6 col-lg-5 project-card__img">
					<img class="" src="./assets/img/multivendor.jpg" alt="Multi Vendor E-Commerce Website" />
				</div>
				<div class="col-md-6 col-lg-7 project-card__info">
					<h3 class="project-card__title">Multi Vendor E-Commerce Website</h3>
					<p class="project-card__description">
						Multi vendor marketplaces are large scale ecommerce stores where multiple vendors can sell their
						products
						and services. Vendors take care of day-to-day sales. In this 21st century, eCommerce has been becoming
						a
						booming industry all over the world.


					</p>
					<p class="project-card__stack">Used stack:</p>
					<ul class="tags">
						<li>html5</li>
						<li>css3</li>
						<li>JavaScript</li>
						<li>PHP</li>
						<li>Ajax</li>
					</ul>
					<a href="" target="_blank" class="project-card__link">Multi Vendor
						E-Commerce
						Website</a>
				</div>
			</div>
			<div class="row project-card" data-toggle="modal" data-target="#portfolioModal" data-portfolio-tag="pharmacy">
				<div class="col-md-6 col-lg-5 project-card__img">
					<img class="" src="./assets/img/img_project_2_mono.png" alt="Pharmacy Management System" />
				</div>
				<div class="col-md-6 col-lg-7 project-card__info">
					<h3 class="project-card__title">Pharmacy Management System</h3>
					<p class="project-card__description">
						Pharmacy Management System allows your pharmacy to process, track, and dispense all prescriptions with
						the
						highest level of security.
					</p>
					<p class="project-card__stack">Used stack:</p>
					<ul class="tags">
						<li>CodeIgnitor</li>
						<li>Bootstrap</li>
						<li>JavaScript</li>
						<li>php</li>
						<li>MYSQL</li>
						<li>Jquery</li>
					</ul>
					<a href="" class="project-card__link">www.pharmacy.triangeltech.com
						[username:saad@hussainsbd.com, Pass: 123456]</a>
				</div>
			</div>
			<div class="row project-card" data-toggle="modal" data-target="#portfolioModal" data-portfolio-tag="landing-pages">
				<div class="col-md-6 col-lg-5 project-card__img">
					<img class="" src="./assets/img/img_blog_1.png" alt="Human Resource & Payroll Management System" />
				</div>
				<div class="col-md-6 col-lg-7 project-card__info">
					<h3 class="project-card__title">Human Resource & Payroll Management System </h3>
					<p class="project-card__description">
						Keep Employees Engaged & Empowered with HCM Cloud. Request a Live Report! Collaborate & Boost
						Engagement
						Through Social, Mobile & Work-Life Capabilities. Payroll Integrations. Mobile-centric Experience.
						Attract
						New Employees. Make HR More Human.
					</p>
					<p class="project-card__stack">Used stack:</p>
					<ul class="tags">
						<li>Laravel</li>
						<li>php</li>
						<li>JavaScript</li>
						<li>Bootstrap</li>
						<li>MYSQL</li>
						<li>Jquery</li>
					</ul>
					<a href="" class="project-card__link">www.hrm-payroll.triangeltech.com
						[username:saad@hussainsbd.com, Pass: 123456]</a>

				</div>
			</div>
		</div>
	</section>
	<!--Portfolio-->

	<!--Testimonials-->
	<div id="testimonials" class="section">
		<div class="background slider-carousel" style="background-image: url(./assets/img/img_bg_main.jpg);">
			<div class="container">
				<div id="carouselTestimonials" class="carousel slide" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#carouselTestimonials" data-slide-to="0" class="active"></li>
						<li data-target="#carouselTestimonials" data-slide-to="1"></li>
						<li data-target="#carouselTestimonials" data-slide-to="2"></li>
						<li data-target="#carouselTestimonials" data-slide-to="3"></li>
						<li data-target="#carouselTestimonials" data-slide-to="4"></li>
					</ol>
					<div class="carousel-inner" role="listbox">
						<div class="carousel-item active">
							<div class="row">
								<div class="col-md-10 col-sm-10 col-10 mr-auto ml-auto">
									<p class="slider-carousel__title">HR Manager,</p>
									<p class="slider-carousel__caption">Leading System Integrator, Bangladesh</p>
									<hr />
									<p class="slider-carousel__description"><q>We thank Mr DORIN for the wonderful job in helping
											us
											develop our program. He was professional, excellent and hard working. Thanks to him, we
											were able
											to achieve our goal on time, and we look forward to continue working with him in the
											future.</q>
									</p>
								</div>
							</div>
						</div>


						<div class="carousel-item">
							<div class="row">
								<div class="col-md-10 col-sm-10 col-10 mr-auto ml-auto">
									<p class="slider-carousel__title">General Manager,</p>
									<p class="slider-carousel__caption">Sports Equipment Company, UK</p>
									<hr />
									<p class="slider-carousel__description"><q>I am really impressed by the quality of services I
											received
											from Developer DORIN. You were right on schedule, charged reasonable prices, were
											professional and
											courteous in dealings, and delivered items well before time. I have got a good
											e-commerce site for
											my products. My revenue has increased because of DORIN and I will definitely use your
											services
											again.</q></p>
								</div>
							</div>
						</div>
						<div class="carousel-item">
							<div class="row">
								<div class="col-md-10 col-sm-10 col-10 mr-auto ml-auto">
									<p class="slider-carousel__title">President of Operations,</p>
									<p class="slider-carousel__caption">Digital Marketing Company in Florida</p>
									<hr />
									<p class="slider-carousel__description"><q>I will admit - originally the thought of
											outsourcing scared
											the hell out of me. As a business owner I am used to control and always having my
											finger on the
											pulse of my employees and contractors. Flatworld has delivered great results and has
											convinced me
											of the value of outsourcing. In the beginning of the relationship between us and Dorin,
											there were
											times when it was difficult to communicate but if you can just get through the first
											week or so
											everything starts to come together.</q></p>
								</div>
							</div>
						</div>
						<div class="carousel-item">
							<div class="row">
								<div class="col-md-10 col-sm-10 col-10 mr-auto ml-auto">
									<p class="slider-carousel__title">CTO,</p>
									<p class="slider-carousel__caption">Classifieds Advertising Firm in San Salvador</p>
									<hr />
									<p class="slider-carousel__description"><q>We would like to express our satisfaction on the
											cooperation regarding the development of our web application. Mr. Dorin did a very
											professional
											job. We are satisfied with the solution given to us and with the communication flow
											through the
											project. </q></p>
								</div>
							</div>
						</div>
						<div class="carousel-item">
							<div class="row">
								<div class="col-md-10 col-sm-10 col-10 mr-auto ml-auto">
									<p class="slider-carousel__title">Coordinator,</p>
									<p class="slider-carousel__caption">Classifieds Advertising Firm in India</p>
									<hr />
									<p class="slider-carousel__description"><q>I wanted to take a moment to thank you for the
											services you
											provided. Your team has been a pleasure to work with, professional and timely. The only
											delay in
											work that we have experienced has been due to our own lack of organization managing our
											projects,
											not yours. Job well done and I hope we can continue to grow together.</q> </p>
								</div>
							</div>
						</div>





					</div>
					<a class="carousel-control-prev" href="#testimonials" role="button" data-slide="prev">
						<span class="carousel-control-prev-icon" aria-hidden="true"></span>
						<span class="sr-only">Previous</span>
					</a>
					<a class="carousel-control-next" href="#testimonials" role="button" data-slide="next">
						<span class="carousel-control-next-icon" aria-hidden="true"></span>
						<span class="sr-only">Next</span>
					</a>
					<div class="slider-carousel__circle">
						<p><i class="" aria-hidden="true">Dorin</i></p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--Testimonials-->

	<div class="something">
		<?php
		// $months = array(
		// 	'January',
		// 	'February',
		// 	'March',
		// 	'April',
		// 	'May',
		// 	'June',
		// 	'July',
		// 	'August',
		// 	'September',
		// 	'October',
		// 	'November',
		// 	'December',
		// );


		// for ($i = 0; $i < 1; ++$i) {
		// 	if ($months[$i] == 1)
		// 		echo "On the 15th of this month I was born!";
		// 	elseif ($months[$i] == 5)
		// 		echo "This is my favorite month of the year. It's already warm enough outside. ";
		// 	elseif ($months[$i] == 2)
		// 		echo "No, this is not my favorite month!";
		// 	else
		// 		echo "No, this is not my favorite month!";
		// }
		// 
		?>
		<?php
		// mt_rand — Генерирует случайное значение методом с помощью генератора простых чисел
		if (mt_rand(0, 1)) {
		?>
			<div class="employees-w">Employees of my company!</div>
		<?php
		} else {
		?>
			<div class=" employees-p">Employees of my company!</div>
		<?php
		}
		?>

		<?php
		$table_data = array(
			array('id' => 10001, 'name' => 'Ankur', 'country' => 'India'),
			array('id' => 20002, 'name' => 'Joy', 'country' => 'USA'),
			array('id' => 10003, 'name' => 'John', 'country' => 'UK'),
			array('id' => 20001, 'name' => 'Steve', 'country' => 'France'),
		);
		?>
		<table class="table-data" border="1">
			<thead>
				<tr>
					<th>ID</th>
					<th>Name</th>
					<th>Country</th>
				</tr>
			</thead>
			<?php
			$count = count($table_data);
			for ($i = 0; $i < $count; $i++) {
				echo '<tr>'
					. '<td>' . $table_data[$i]['id'] . '</td>'
					. '<td>' . $table_data[$i]['name'] . '</td>'
					. '<td>' . $table_data[$i]['country'] . '</td>'
					. '</tr>';
			}
			?>

		</table>

	</div>
	

	<!--Blog-->
	<section id="blog" class="container section">
		<div class="row">
			<div class="col-md-12">
				<h2 id="blog_header" class="section__title">Latest Posts_</h2>
			</div>
		</div>

		<div class="row post-cards">
			<div class="col-md-4">
				<a href="./blog.php">
					<div class="post-cards__card">
						<div class="post-cards__img">
							<img src="./assets/img/img_blog_1.png" alt="blog_img" />
						</div>
						<div class="post-cards__info">
							<p class="post-cards__date">October 22, 2017</p>
							<h3 class="post-cards_title">How to use css-preprocessor</h3>
							<p class="post-cards_description">In time writing HTML and CSS may feel a bit taxing, requiring a
								lot of
								the same tasks to be completed over and over again.
								Tasks such as closing tags in HTML.
							</p>
						</div>
					</div>
				</a>
			</div>
			<div class="col-md-4">
				<a href="./blog.php">
					<div class="post-cards__card">
						<div class="post-cards__img">
							<img src="./assets/img/img_blog_2.png" alt="blog_img" />
						</div>
						<div class="post-cards__info">
							<p class="post-cards__date">January 22, 2020</p>
							<h3 class="post-cards_title">How I organize my work with code</h3>
							<p class="post-cards_description">I'd be curious to see how everyone organizes their source code.

								Let's see some screenshots or terminal dumps of your set up.

								Here's what I've been doing for the last 5 or 6 months
							</p>
						</div>
					</div>
				</a>
			</div>
			<div class="col-md-4">
				<a href="./blog.php">
					<div class="post-cards__card">
						<div class="post-cards__img">
							<img src="./assets/img/img_blog_3.png" alt="blog_img" />
						</div>
						<div class="post-cards__info">
							<p class="post-cards__date">march 02, 2020</p>
							<h3 class="post-cards_title">SVG sprites vs Icon Font</h3>
							<p class="post-cards_description">At some point, every front end developer has to decide what kind
								of icon
								system wants to build. Right now we have two valuable players - SVGs and icon fonts.
							</p>
						</div>
					</div>
				</a>
			</div>
		</div>
	</section>
	<!--Blog-->

	<!--Contact-->
	<div class="background" style="background-image: url(./assets/img/img_bg_main.jpg)">
		<div id="contact" class="container section">
			<div class="row">
				<div class="col-md-12">
					<p id="contacts_header" class="section__title">Get in touch_</p>
				</div>
			</div>
			<div class="row contacts">
				<div class="col-md-5 col-lg-4">
					<div class="contacts__list">
						<dl class="contact-list">
							<dt>Phone:</dt>
							<dd><a href="tel:01685040674">+373 67496303</a></dd>
							<dt>GitHub</dt>
							<dd><a href="https://github.com/raselhasandurjoy">raselhasandurjoy</a></dd>
							<dt>Email:</dt>
							<dd><a href="gavrilitadorin5@gmail.com">raselhasandurjoy@gmail.com</a></dd> <br>
							<dt></dt>
							<dd>
								<div class="contacts__social">
									<p class="personal-profile__social">
										<a href="https://github.com/DorinGavrilita" target="_blank"><i class="fa fa-github fa-2x"></i></a>&nbsp;
										&nbsp; <a href="https://www.linkedin.com/in/dorin-gavrilita-636476218/" target="_blank">
											<i class="fa fa-linkedin-square fa-2x"></i></a>&nbsp;
										&nbsp; <a href="https://www.facebook.com/profile.php?id=100008440155085" target="_blank">
											<i class="fa fa-facebook-square fa-2x"></i></a>
									</p>
								</div>
							</dd>
						</dl>
					</div>
					<?php
					echo "Current date and time.<br>";
					echo date(DATE_RSS);
					?>
				</div>
				<div class="col-md-7 col-lg-5">

					<div class="contacts__form">
						<p class="contacts__form-title">Or just write me a letter here_</p>
						<div class="msg"></div>
						<form class="js-form" method="post" action="mail_handler.php">
							<div class="form-group">
								<input class="form-field js-field-name" name="name" id="name" type="text" placeholder="Your name" required="" />
								<span class="form-validation"></span>
								<span class="form-invalid-icon"><i class="mdi mdi-close" aria-hidden="true"></i></span>
							</div>
							<div class="form-group">
								<input class="form-field js-field-email" name="email" id="email" type="email" placeholder="Your e-mail" required="" />
								<span class="form-validation"></span>
								<span class="form-invalid-icon"><i class="mdi mdi-close" aria-hidden="true"></i></span>
							</div>
							<div class="form-group">
								<textarea class="form-field js-field-message" name="message" id="message" placeholder="Type the message here" required=""></textarea>
								<span class="form-validation"></span>
								<span class="form-invalid-icon"><i class="mdi mdi-close" aria-hidden="true"></i></span>
							</div>
							<button class="site-btn site-btn--form" id="submit" name="submit" type="submit" onclick="myFunction()" value="Send">Send</button>
						</form>
					</div>
					<div class="footer">
						<p>© 2022 DORIN. All Rights Reserved</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--Contact-->
	<script>
		function myFunction() {
			const nameInput = document.querySelector('#name');
			const emailInput = document.querySelector('#email');
			const messageInput = document.querySelector('#message');
			const msg = document.querySelector('.msg');

			if (nameInput.value === '' || emailInput.value === '' || messageInput.value === '') {
				msg.innerHTML = '';
			} else {
				msg.classList.add('error');
				msg.innerHTML = 'Your Message has been Sent!';

				// Remove error after 3 seconds
				setTimeout(() => msg.remove(), 6000);
			}


		}
	</script>

	<script src="./assets/js/jquery-2.2.4.min.js"></script>
	<script src="./assets/js/popper.min.js"></script>
	<script src="./assets/js/bootstrap.min.js"></script>
	<script src="./assets/js/menu.js"></script>
	<script src="./assets/js/jquery.waypoints.js"></script>
	<script src="./assets/js/progress-list.js"></script>
	<script src="./assets/js/section.js"></script>
	<script src="./assets/js/portfolio-filter.js"></script>
	<script src="./assets/js/slider-carousel.js"></script>
	<script src="./assets/js/mobile-menu.js"></script>

	<script src="./assets/js/mbclicker.min.js"></script>
	<script src="./assets/js/site-btn.js"></script>
	<script src="./assets/js/style-switcher.js"></script>


</html>