<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <meta http-equiv="X-UA-Compatible" content="ie=edge" />

    <meta name="description" content="" />

    <meta name="author" content="" />

    <title>Dorin Profile</title>

    <link rel="stylesheet" href="./assets/css/color.css" />

    <link href="https://fonts.googleapis.com/css?family=Roboto|Roboto+Mono|Inconsolata" rel="stylesheet" />

    <link rel="stylesheet" href="./assets/css/color.css" />
    <link rel="stylesheet" href="./assets/css/style.css" />
    <link href="https://fonts.googleapis.com/css?family=Roboto|Roboto+Mono|Inconsolata" rel="stylesheet" />

    <link href="https://cdn.materialdesignicons.com/2.0.46/css/materialdesignicons.min.css" rel="stylesheet" />

    <script type="text/javascript">
        (function(d, w, c) {
            (w[c] = w[c] || []).push(function() {
                try {
                    w.yaCounter41478434 = new Ya.Metrika({
                        id: 41478434,
                        clickmap: true,
                        trackLinks: true,
                        accurateTrackBounce: true,
                        webvisor: true,
                        trackHash: true
                    });
                } catch (e) {}
            });
            var n = d.getElementsByTagName("script")[0],
                s = d.createElement("script"),
                f = function() {
                    n.parentNode.insertBefore(s, n);
                };
            s.type = "text/javascript";
            s.async = true;
            s.src = "../../mc.yandex.ru/metrika/watch.js";
            if (w.opera == "[object Opera]") {
                d.addEventListener("DOMContentLoaded", f, false);
            } else {
                f();
            }
        })(document, window, "yandex_metrika_callbacks");
    </script>
    <noscript>
        <div><img src="https://mc.yandex.ru/watch/41478434" style="position:absolute; left:-9999px;" alt="" /></div>
    </noscript>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>



    <!--Switcher-->

    <div class="style-switcher">

        <span class="style-switcher__control"></span>

        <div class="style-switcher__list">

            <a class="style-switcher__link style-switcher__link--color"></a>

            <a class="style-switcher__link style-switcher__link--mono"></a>

        </div>

    </div>

    <!--Switcher-->



    <!--Main menu-->

    <div class="menu">

        <div class="container">

            <div class="row">

                <div class="menu__wrapper d-none d-lg-block col-md-12">

                    <nav class="">

                        <ul>

                            <li><a href="./index.php">Home</a></li>

                            <li><a href="#posts">other posts</a></li>

                            <li><a href="#contact">Contact</a></li>

                        </ul>

                    </nav>

                </div>

                <div class="menu__wrapper col-md-12 d-lg-none">

                    <div class="menu__mobile-button">

                        <span><i class="fa fa-bars" aria-hidden="true"></i></span>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <!--Main menu-->



    <!-- Mobile menu -->

    <div class="mobile-menu d-lg-none">

        <div class="container">

            <div class="mobile-menu__close">

                <span><i class="mdi mdi-close" aria-hidden="true"></i></span>

            </div>

            <nav class="mobile-menu__wrapper">

                <ul>

                    <li><a href="./index.php">Home</a></li>

                    <li><a href="#other_posts">other posts</a></li>

                    <li><a href="#contact">Contact</a></li>

                </ul>

            </nav>

        </div>

    </div>

    <!-- Mobile menu -->



    <!--Header-->

    <header class="background blog-header" style="background-image: url(./assets/img/img_bg_main.jpg)">

    </header>

    <!--Header-->



    <!--Article-->

    <div class="container">

        <div class="article">

            <div class="row">

                <div class="col-md-12">

                    <a class="article__back-link" href="./index.php"><i class="fa fa-long-arrow-left" aria-hidden="true"></i>Back</a>

                    <p class="article__title">How I organize my work with code</p>

                    <p class="article_date">November, 28, 2022</p>

                    <div>
                        <?php
                        echo "Perhaps the most important step to take towards ease of reproducibility is to be organized. Ideally, the names of files and subdirectories are self-explanatory, so that one can tell at a glance what data files contain, what scripts do, and what came from what.";
                        ?>

                        <form action="" method="POST">
                            <input class="advice-btn" type="submit" name="submit" value="Get advice!">
                        </form>
                    </div>
                    <div class="advice">

                        <?php
                        $arrAdvice = array(
                            "Encapsulate everything within one directory. Have a single directory for a project, containing all of the data, code, and results for that project. This makes it easier to find things, or to zip it all up and hand it off to someone else.",

                            "Separate raw data from derived data and other data summaries. I prefer to have a subdirectory RawData/ and then another subdirectory Data/, or perhaps two other subdirectories DerivedData/ (containing reformatted, reorganized, or cleaned data files) and DataSummaries/ (containing summary information, like lists of subjects or genetic markers, or summary statistics extracted from the primary data in order to make a particular graph). This makes it easier to tell the nature of the data in a file, by its location within the project directory.",

                            "Separate the data from the code. I prefer to put code and data in separate subdirectories. I’ll have an R/ subdirectory and perhaps also Python/ and Ruby/ subdirectories.",

                            "Use relative paths (never absolute paths). If you encapsulate all data and code within a single project directory, then you can refer to data files with relative paths (e.g., ../RawData/some_file.csv). If you were to use an absolute path (like ~/Projects/SomeProject/RawData/some_file.csv or C:\Users\SomeOne\Projects\SomeProject\RawData\some_file.csv) then anyone who wanted to reproduce your results but had the project placed in some other location would have to go in and edit all of those directory/file names.",

                            "Choose file names carefully. I try not to change the names of raw data files that I get from a collaborator (though I’m often tempted to replace spaces with underscores). But scripts need names, and files with derived or cleaned data need names. Be as clear and explicit as possible. The same holds for the variables and functions within your scripts.",

                            "Avoid using “final” in a file name. Nothing is ever final, and if you call something “final” you’ll end up with things like cleandata_final_rev3.csv. If you want to keep multiple versions of a file, just append a number, like cleandata_v8.csv.",

                            "Write ReadMe files. Even if you’ve organized and named things perfectly, you’ll still want to include some documentation that explains what’s what. A ReadMe.txt file (or ReadMe.md, for Markdown) in the main directory and perhaps also in each subdirectory may be sufficient. Describe the files and the process. And keep the ReadMe files up to date as things are added or changed."
                        );

                        if (isset($_POST['submit'])) {
                            for ($i = 0; $i < count($arrAdvice); $i++) {

                                echo '      ' . $i + 1 . '.' .  $arrAdvice[$i] . "<br>\r\n<br>\r\n";
                            }
                        }else echo "If you want tips, hit the button!";

                        ?>

                    </div>


                    <figure>

                        <img src="./assets/img/img_article_photo.jpg" />

                        <figcaption>This is how I organize my HTML, CSS and PHP files</figcaption>

                    </figure>

                    <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut

                        labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco

                        laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in

                        voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat

                        non proident, sunt in culpa qui.

                    </p>

                    <p class="article__share">Share this post:

                        <a><i class="fa fa-linkedin-square"></i></a>

                        <a><i class="fa fa-facebook-square"></i></a>

                    </p>

                </div>

            </div>

        </div>

    </div>

    <!--Article-->



    <!--Other Posts-->

    <section id="posts" class="container section">

        <div class="row">

            <div class="col-md-12">

                <h2 id="other_posts" class="section__title">Other Posts_</h2>

            </div>

        </div>



        <div class="row posts">

            <div class="col-md-5 mr-auto">

                <div class="posts__item">

                    <a href="./blog.php">

                        <h3 class="posts__title">What’s new in the IT Industry?</h3>

                        <p class="posts__description">Invitation excellence imprudence understood it continuing to.

                            Ye show done an into.</p>

                    </a>

                </div>

                <div class="posts__item">

                    <a href="./blog.php">

                        <h3 class="posts__title">How I organize my work with code</h3>

                        <p class="posts__description">Invitation excellence imprudence understood it continuing to.

                            Ye show done an into.</p>

                    </a>

                </div>

                <div class="posts__item">

                    <a href="./blog.php">

                        <h3 class="posts__title">How to use css-preprocessor</h3>

                        <p class="posts__description">Invitation excellence imprudence understood it continuing to.

                            Ye show done an into.</p>

                    </a>

                </div>

            </div>

            <div class="col-md-5 mr-auto">

                <div class="posts__item">

                    <a href="./blog.php">

                        <h3 class="posts__title">What’s new in the IT Industry?</h3>

                        <p class="posts__description">Invitation excellence imprudence understood it continuing to.

                            Ye show done an into.</p>

                    </a>

                </div>

                <div class="posts__item">

                    <a href="./blog.php">

                        <h3 class="posts__title">How I organize my work with code</h3>

                        <p class="posts__description">Invitation excellence imprudence understood it continuing to.

                            Ye show done an into.</p>

                    </a>

                </div>

                <div class="posts__item">

                    <a href="./blog.php">

                        <h3 class="posts__title">How to use css-preprocessor</h3>

                        <p class="posts__description">Invitation excellence imprudence understood it continuing to.

                            Ye show done an into.</p>

                    </a>

                </div>

            </div>

        </div>

    </section>

    <!--Other Posts-->



    <!--Contact-->
    <div class="background" style="background-image: url(./assets/img/img_bg_main.jpg)">
        <div id="contact" class="container section">
            <div class="row">
                <div class="col-md-12">
                    <p id="contacts_header" class="section__title">Get in touch_</p>
                </div>
            </div>
            <div class="row contacts">
                <div class="col-md-5 col-lg-4">
                    <div class="contacts__list">
                        <dl class="contact-list">
                            <dt>Phone:</dt>
                            <dd><a href="tel:+373 67496303">+373 67496303</a></dd>
                            <dt>GitHub</dt>
                            <dd><a href="https://github.com/DorinGavrilita">DorinGavrilita</a></dd>
                            <dt>Email:</dt>
                            <dd><a href="gavrilitadorin5@gmail.com">gavrilitadorin5@gmail.com</a></dd> <br>
                            <dt></dt>
                            <dd>
                                <div class="contacts__social">
                                    <p class="personal-profile__social">
                                        <a href="https://github.com/DorinGavrilita" target="_blank"><i class="fa fa-github fa-2x"></i></a>&nbsp;
                                        &nbsp; <a href="https://www.linkedin.com/in/dorin-gavrilita-636476218/" target="_blank">
                                            <i class="fa fa-linkedin-square fa-2x"></i></a>&nbsp;
                                        &nbsp; <a href="https://www.facebook.com/profile.php?id=100008440155085" target="_blank">
                                            <i class="fa fa-facebook-square fa-2x"></i></a>
                                    </p>
                                </div>
                            </dd>
                        </dl>
                    </div>

                </div>
                <div class="col-md-7 col-lg-5">

                    <div class="contacts__form">
                        <p class="contacts__form-title">Or just write me a letter here_</p>
                        <div class="msg"></div>
                        <form class="js-form" method="post" action="mail_handler.php">
                            <div class="form-group">
                                <input class="form-field js-field-name" name="name" id="name" type="text" placeholder="Your name" required="" />
                                <span class="form-validation"></span>
                                <span class="form-invalid-icon"><i class="mdi mdi-close" aria-hidden="true"></i></span>
                            </div>
                            <div class="form-group">
                                <input class="form-field js-field-email" name="email" id="email" type="email" placeholder="Your e-mail" required="" />
                                <span class="form-validation"></span>
                                <span class="form-invalid-icon"><i class="mdi mdi-close" aria-hidden="true"></i></span>
                            </div>
                            <div class="form-group">
                                <textarea class="form-field js-field-message" name="message" id="message" placeholder="Type the message here" required=""></textarea>
                                <span class="form-validation"></span>
                                <span class="form-invalid-icon"><i class="mdi mdi-close" aria-hidden="true"></i></span>
                            </div>
                            <button class="site-btn site-btn--form" id="submit" name="submit" type="submit" onclick="myFunction()" value="Send">Send</button>
                        </form>
                    </div>
                    <div class="footer">
                        <p>© 2022 DORIN. All Rights Reserved</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Contact-->



    <script src="./assets/js/jquery-2.2.4.min.js"></script>

    <script src="./assets/js/popper.min.js"></script>

    <script src="./assets/js/bootstrap.min.js"></script>

    <script src="./assets/js/menu.js"></script>

    <script src="./assets/js/jquery.waypoints.js"></script>

    <script src="./assets/js/progress-list.js"></script>

    <script src="./assets/js/section.js"></script>

    <script src="./assets/js/mobile-menu.js"></script>

    <script src="./assets/js/contacts.js"></script>

    <script src="./assets/js/mbclicker.min.js"></script>

    <script src="./assets/js/site-btn.js"></script>

    <script src="./assets/js/style-switcher.js"></script>

</body>

</html>